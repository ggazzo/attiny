### V 1.0.1 19/05/2016
 - Compliant with Arduino IDE library specification 1.5 rev.2

### V 1.0.0 17/05/2016
 - First version