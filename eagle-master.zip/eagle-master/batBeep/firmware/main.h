#ifndef _MAIN_H
#define _MAIN_H

#include <inttypes.h>

uint16_t volatile current_adc_value;

#endif
