#ifndef _SPI_H
#define _SPI_H


void SetLed(uint8_t,uint8_t,uint8_t,uint8_t);



#endif
