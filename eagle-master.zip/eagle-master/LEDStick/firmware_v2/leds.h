#ifndef _LEDS_H
#define _LEDS_H

void SetLed(uint8_t,uint8_t,uint8_t,uint8_t);
void SetLed12(uint8_t,uint16_t,uint16_t,uint16_t);
void SetDC(uint8_t,uint8_t,uint8_t,uint8_t);
void LED_init(void);

#endif
