#ifndef _ADC_H
#define _ADC_H

extern volatile uint16_t adc_value;

void ADC_Init (void);

#endif
