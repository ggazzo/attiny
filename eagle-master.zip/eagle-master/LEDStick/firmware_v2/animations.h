#ifndef _ANIMATIONS_H
#define _ANIMATIONS_H

void ani_fullcolor(void);
void ani_c3d2(void);
void ani_rainbow(void);
void ani_battery(void);
void ani_sectors3(void);
void ani_sectors12(void);
void ani_redblue(void);
void ani_greenyellow(void);
void ani_bluewhite(void);

#endif
