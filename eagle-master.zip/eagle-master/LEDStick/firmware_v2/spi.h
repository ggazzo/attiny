#ifndef _SPI_H
#define _SPI_H

void SPI_send(uint8_t);
void SPI_init(void);

#endif
