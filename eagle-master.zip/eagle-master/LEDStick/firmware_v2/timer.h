#ifndef _TIMER_H
#define _TIMER_H

extern volatile uint8_t timeout;
extern volatile uint8_t initialized;
extern volatile uint8_t newdata;

void TIMER1_Init (void);


#endif
